# ChimeLauncher v1.3.8 マニュアル資料

本文は docs/20261006_chimelauncher-user-manual.md です。本文で参照する旧版・現行版の画像と、PDF生成スクリプトを同梱しています。PDFは別配布です。

GitHubで読む: https://github.com/tnk962/ChimeLauncher/blob/main/docs/20261006_chimelauncher-user-manual.md
PDF: https://github.com/tnk962/ChimeLauncher/blob/main/output/pdf/20261006_chimelauncher-user-manual.pdf

PDFを再生成する場合は、このZIPを展開したルートから python docs/20261006_build-manual.py を実行します。reportlab・Pillow、Popplerのpdftoppm、/Library/Fonts/Arial Unicode.ttf が必要です。macOS以外では生成スクリプトの日本語フォントパスを環境に合わせてください。フォントそのものは同梱していません。
